/**Write a Java Program to print as below.
 * Created by JANVI on 30/08/2019.
 */
public class ThirdPrint {

    public static void main (String [] args){

        System.out.println(" ''+-------------------------+'' ");


        System.out.println(" ''|                         |'' ");

        System.out.println(" ''|     CORNER STORE        |'' ");
        System.out.println(" ''|                         |'' ");
        System.out.println(" ''|   2015-03-29  04:38PM   |'' ");
        System.out.println(" ''|                         |'' ");
        System.out.println(" ''|    Gallons:    10.870   |'' ");
        System.out.println(" ''|  Price/gallo: $2.089    |'' ");
        System.out.println(" ''|                         |'' ");
        System.out.println(" ''|    Fuel total:$22.71    |'' ");


        System.out.println(" ''+-------------------------+'' ");
    }
}



























